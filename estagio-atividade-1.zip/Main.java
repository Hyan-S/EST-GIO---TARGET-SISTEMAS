//Atividade N°01
public class Main
{
	public static void main(String[] args) {
	    int INDICE = 13, SOMA = 0, K = 0;
	    
	    //Loop
	    while(K < INDICE){
	        K +=1;
	        SOMA +=K;
	    }
	    //Impressão da variável
	    System.out.print("O valor da SOMA é: " + SOMA);
    }
}